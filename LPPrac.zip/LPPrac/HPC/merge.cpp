#include<iostream>
#include<omp.h>
#include<sys/time.h>

using namespace std;

void p_bubble(int a[],int count)
{
	//omp_set_num_threads(20);
	static int swap_flag=0;
	
		for(int i=0;i<count-2;i++)
		{
			if(i%2==0)
			{
				#pragma omp parallel for
				for(int j=0;j<(count/2);j++)
				{
					int temp;
					if(a[2*j]>a[2*j+1])
					{
						temp=a[2*j];
						a[2*j]=a[2*j+1];
						a[2*j+1]=temp;
						swap_flag=1;
					}
				} 
			}
			else
			{
				#pragma omp parallel for
				for(int j=0;j<(count-1)/2;j++)
				{
					int temp;
					if(a[2*j+1]>a[2*j+2])
					{
						temp=a[2*j+1];
						a[2*j+1]=a[2*j+2];
						a[2*j+2]=temp;
						swap_flag=1;
					}
				}
				
			}
		}	
	
}

void merge(int *a,int start,int mid,int end)
{
	int len=(end-start)+1;
	int tem[len];
	
	int i=start;
	int j=mid+1;
	int cur=0;
	
	while(i<=mid && j<=end)
	{
		if(a[i]>a[j])
		{
			tem[cur]=a[i];
			cur++;
			i++;
		}
		else
		{
			tem[cur]=a[j];
			cur++;
			j++;
		}
	}
	
	if(i<=mid)
	{
		while(i<=mid)
		{
			tem[cur]=a[i];
			cur++;
			i++;
		}
	}
	
	if(j<=end)
	{
		while(j<=end)
		{
			tem[cur]=a[j];
			cur++;
			j++;
		}
	}
	
	cur=0;
	for(int i=start;i<=end;i++)
	{
		a[i]=tem[cur];
		cur++;
	}
}
void p_merge(int *a,int start,int end)
{
	if(start<end)
	{
		int mid=(start+end)/2;
		#pragma omp parallel sections
		{
			#pragma omp section
			p_merge(a,start,mid);
			
			#pragma omp section
			p_merge(a,mid+1,end);
			
		}
		merge(a,start,mid,end);
	}
}

void mergeSort(int *a,int start,int end)
{
	if(start<end)
	{
		int mid=(start+end)/2;
		mergeSort(a,start,mid);
		mergeSort(a,mid+1,end);
		merge(a,start,mid,end);
	}
	
}

void bubbleSort(int *a,int len)
{
	for(int i=0;i<len;i++)
	{
		for(int j=0;j<len;j++)
		{
			if(a[j]>a[j+1])
			{
				int temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
}


void print(int *a,int n)
{
	for(int i=0;i<n;i++)
		cout<<a[i]<<" ";
	cout<<endl;
}

int main(int argc,char* argv[])
{
	omp_set_num_threads(3);
	
	double startmp,start,endmp,end;
	int n;
	cout<<"Enter size"<<endl;
	cin>>n;
	
	int a[n];
	 for(int i=0;i<n;i++)
    {
        a[i] = rand()%500;
       // b[i]=a[i];
    }
	//print(a,len);
	
	//gettimeofday(&start,NULL);
	startmp=omp_get_wtime();
	p_merge(a,0,n-1);
	endmp=omp_get_wtime();
	
	//gettimeofday(&stop,NULL);
	
	cout<<"Time taken Parallel merge	"<<endmp-startmp<<endl;
	
	//print(a,len);
	startmp=omp_get_wtime();
	p_bubble(a,n);
	endmp=omp_get_wtime();
	cout<<"Time taken Parallel bubble"<<endmp-startmp<<endl;
	
	startmp=omp_get_wtime();
	bubbleSort(a,n);
	endmp=omp_get_wtime();
	cout<<"Time taken Bubble"<<endmp-startmp<<endl;
	
	
	
	
	//print(a,len);
return 0;
}
