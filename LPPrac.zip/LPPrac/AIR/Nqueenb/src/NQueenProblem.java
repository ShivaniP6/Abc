public class NQueenProblem
{
	final int N=4;
	void print(int board[][])
	{
		for(int i=0;i<N;i++)
		{
			for(int j=0;j<N;j++)
			{
				System.out.print(" "+board[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	boolean isSafe(int board[][],int row,int col)
	{
		int i,j;
		for(i=0;i<col;i++)
			if(board[row][i]==1)
				return false;
		for(i=row,j=col;i>=0 && j>=0; i--,j--)
		{
			if(board[i][j]==1)
				return false;
			
		}
		for(i=row,j=col; i<N && j>=0; i++,j--)
			if(board[i][j]==1)
				return false;
	
		return true;
	}
	
	boolean solveNQuntil(int board[][],int col)
	{
		if(col>=N)
			return true;
		for(int i=0;i<N;i++)
		{
			if(isSafe(board,i,col)==true)
			{
				board[i][col]=1;
				
				if(solveNQuntil(board,col+1)==true)
					return true;
				
				board[i][col]=0;
			}
			
		}
		return false;
		
	}
	
	boolean SolveNQ()
	{
		int board[][]= {{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
		
		if(solveNQuntil(board,0)==false)
		{
			System.out.print("No solution exixt");
			return false;
		}
		
		print(board);
		return true;
	}


public static void  main(String args[])
{
	NQueenProblem Queen = new NQueenProblem(); 
    Queen.SolveNQ();
}
}