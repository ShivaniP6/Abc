import java.util.Arrays;

public class Bnb {
	final int N=4;
	
	void print(int board[][])
	{
		for(int i=0;i<N;i++)
		{
			for(int j=0;j<N;j++)
			{
				System.out.print(" "+board[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	boolean isSafe(int row,int col,int backslash[][],int slash[][],boolean rowlookup[],
			boolean slashlookup[],boolean backslashlookup[])
	{
		if(rowlookup[row] || backslashlookup[backslash[row][col]] || slashlookup[slash[row][col]])
			return false;
	return true;
	}
	
	boolean solveNQuntil(int board[][],int col,int slash[][],int backslash[][],
			boolean rowlookup[],boolean slashlookup[],boolean backslashlookup[])
	{
		if(col>=N)
			return true;
		
		for(int i=0;i<N;i++)
		{
			if(isSafe(i,col,backslash,slash,rowlookup,slashlookup,backslashlookup))
			{
				board[i][col]=1;
				rowlookup[i]=true;
				slashlookup[slash[i][col]]=true;
				backslashlookup[backslash[i][col]]=true;
				
				if(solveNQuntil(board,col+1,slash,backslash,rowlookup,slashlookup,backslashlookup)==true)
				{
					return true;
				}
				
				board[i][col]=0;
				rowlookup[i]=false;
				slashlookup[slash[i][col]]=false;
				backslashlookup[backslash[i][col]]=false;
				
			}
		}
		return false;
	}
	
	boolean solveNQ()
	{
		int board[][]=new int[N][N];
		
		for(int i=0;i<N;i++)
		{
			for(int j=0;i<N;i++)
			{
				board[i][j]=0;
			}
		}
		
		int backslash[][]=new int[N][N];
		int slash[][]=new int[N][N];
		
		for(int r=0;r<N;r++)
		{
			for(int c=0;c<N;c++)
			{
				backslash[r][c]=r-c+N-1;
				slash[r][c]=r+c;
			}
		}
		
		boolean rowlookup[]= new boolean[N];
		Arrays.fill(rowlookup, false);
		boolean slashlookup[]=new boolean[2*N-1];
		Arrays.fill(slashlookup, false);
		boolean backslashlookup[]=new boolean[2*N-1];
		Arrays.fill(backslashlookup,false);
		
		if(solveNQuntil(board, 0, slash, backslash, rowlookup, slashlookup, backslashlookup)==false)
		{
			System.out.print("Solution does not exist");
			return false;
		}
		
		print(board);
		return true;
		
		
	}
	

	public static void main(String[] args) {
		Bnb b=new Bnb();
		b.solveNQ();
		
		
	}
}
