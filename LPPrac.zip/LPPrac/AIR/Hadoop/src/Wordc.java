import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.yarn.webapp.hamlet.Hamlet.I;

public class Wordc {
	public static class A extends Mapper<Object,Text,Text, IntWritable>
	{
		private static IntWritable one=new IntWritable(1);
		private Text word=new Text();
		public void reduce(Object key,Text value, Context context) throws Exception
		{
			StringTokenizer itr=new StringTokenizer(value.toString());
			while(itr.hasMoreTokens())
			{
				word.set(itr.nextToken());
				context.write(word, one);
			}
		}
	}
	
	
	public static class B extends Reducer<Text, IntWritable, Text, IntWritable>
	{
		IntWritable res=new IntWritable();
		
		void red(Text key,Iterable<IntWritable> values, Context context) throws IOException, InterruptedException
		{
			int sum=0;
			for(IntWritable val: values )
			{
				sum+=val.get();
				context.write(key,res);
			}
		}
	}
	
	public static void Main(String args[]) throws Exception
	{
		Configuration configuration=new Configuration();
		Job job=Job.getInstance(configuration, "word count");
		
		job.setMapperClass(A.class);
		job.setCombinerClass(B.class);
		job.setReducerClass(B.class);
		
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);
		
		FileInputFormat.addInputPath(job,new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true)?0:1);
	}

}
